import DemoForm from "./DemoForm";
import DemoFormWithZOD from "./DemoFormWithZOD";
import ProductForm from "./ProductForm";
import AssignmentZODForm from "./AssignmentZODForm";
export default function App() {
  return (
    <div className="min-h-screen">
      {/* <ProductForm /> */}
      {/* <DemoForm/> */}
      {/* <DemoFormWithZOD/> */}
      <AssignmentZODForm/>
    </div>
  );
}
